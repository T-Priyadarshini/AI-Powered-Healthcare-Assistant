package com.priya.microservices.patient.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.priya.microservices.patient.model.Patient;
import com.priya.microservices.patient.repository.PatientRepository;

@RestController
@RequestMapping("/patients")
public class PatientController {
    @Autowired private PatientRepository repo;

    @PostMapping
    public Patient create(@RequestBody Patient p) { return repo.save(p); }

    @GetMapping("/{id}")
    public ResponseEntity<Patient> get(@PathVariable Long id) {
        return repo.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
}
