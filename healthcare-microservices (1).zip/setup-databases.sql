-- Create databases and tables for the healthcare microservices (run in MySQL)
CREATE DATABASE IF NOT EXISTS patientdb;
CREATE DATABASE IF NOT EXISTS doctordb;
CREATE DATABASE IF NOT EXISTS appointmentdb;

USE patientdb;
CREATE TABLE IF NOT EXISTS patients (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(100),
  phone VARCHAR(20),
  age INT,
  gender VARCHAR(10)
);

USE doctordb;
CREATE TABLE IF NOT EXISTS doctors (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  specialty VARCHAR(100),
  email VARCHAR(100),
  phone VARCHAR(20),
  available BOOLEAN DEFAULT TRUE
);

USE appointmentdb;
CREATE TABLE IF NOT EXISTS appointments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT,
  doctor_id INT,
  symptoms VARCHAR(1000),
  scheduled_time DATETIME,
  status VARCHAR(20),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
