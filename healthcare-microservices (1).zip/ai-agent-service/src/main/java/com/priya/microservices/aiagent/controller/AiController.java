package com.priya.microservices.aiagent.controller;

import org.springframework.web.bind.annotation.*;
import com.priya.microservices.aiagent.dto.AiRequest;
import com.priya.microservices.aiagent.dto.AiResponse;

@RestController
public class AiController {

    @PostMapping("/analyze")
    public AiResponse analyze(@RequestBody AiRequest req) {
        // Simple rule-based fallback to avoid needing external API keys
        String s = req.getSymptoms().toLowerCase();
        if (s.contains("chest") || s.contains("breath")) {
            return new AiResponse("Cardiology", "HIGH", "Please seek urgent attention."); 
        } else if (s.contains("fever") || s.contains("cough")) {
            return new AiResponse("General Medicine", "MEDIUM", "Visit general physician."); 
        } else {
            return new AiResponse("General Medicine", "LOW", "Routine consultation."); 
        }
    }
}
