package com.priya.microservices.aiagent.dto;
public class AiRequest { private String patientName; private String symptoms; public String getPatientName(){return patientName;} public void setPatientName(String p){this.patientName=p;} public String getSymptoms(){return symptoms;} public void setSymptoms(String s){this.symptoms=s;} }
