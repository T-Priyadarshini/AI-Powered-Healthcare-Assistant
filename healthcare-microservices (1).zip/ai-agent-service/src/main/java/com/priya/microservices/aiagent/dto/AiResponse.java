package com.priya.microservices.aiagent.dto;
public class AiResponse {
    private String recommendedSpecialty; private String urgency; private String message;
    public AiResponse(){} 
    public AiResponse(String recommendedSpecialty, String urgency, String message){ this.recommendedSpecialty=recommendedSpecialty; this.urgency=urgency; this.message=message; }
    public String getRecommendedSpecialty(){return recommendedSpecialty;} public void setRecommendedSpecialty(String s){this.recommendedSpecialty=s;}
    public String getUrgency(){return urgency;} public void setUrgency(String u){this.urgency=u;} public String getMessage(){return message;} public void setMessage(String m){this.message=m;}
}
