package com.priya.microservices.appointment.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import java.util.List;
import com.priya.microservices.appointment.dto.DoctorDto;

@FeignClient(name = "DOCTOR-SERVICE")
public interface DoctorClient {
    @GetMapping("/doctors/by-specialty/{specialty}")
    List<DoctorDto> findBySpecialty(@PathVariable("specialty") String specialty);
}
