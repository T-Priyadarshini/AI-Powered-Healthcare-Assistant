package com.priya.microservices.appointment.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.priya.microservices.appointment.service.AppointmentService;
import com.priya.microservices.appointment.model.Appointment;
import java.time.LocalDateTime;

@RestController
@RequestMapping("/appointments")
public class AppointmentController {
    @Autowired private AppointmentService svc;

    @PostMapping
    public Appointment create(@RequestBody CreateAppointmentRequest req) {
        return svc.createAppointment(req.getPatientId(), req.getSymptoms(), req.getPreferredTime());
    }

    @GetMapping("/{id}")
    public Appointment get(@PathVariable Long id) { return svc.getById(id); }
}

class CreateAppointmentRequest {
    private Long patientId; private String symptoms; private LocalDateTime preferredTime;
    public Long getPatientId(){return patientId;} public void setPatientId(Long id){this.patientId=id;}
    public String getSymptoms(){return symptoms;} public void setSymptoms(String symptoms){this.symptoms=symptoms;}
    public LocalDateTime getPreferredTime(){return preferredTime;} public void setPreferredTime(LocalDateTime preferredTime){this.preferredTime=preferredTime;}
}
