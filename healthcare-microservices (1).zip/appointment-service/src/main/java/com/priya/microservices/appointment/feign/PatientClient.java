package com.priya.microservices.appointment.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import com.priya.microservices.appointment.dto.PatientDto;

@FeignClient(name = "PATIENT-SERVICE")
public interface PatientClient {
    @GetMapping("/patients/{id}")
    PatientDto getPatient(@PathVariable("id") Long id);
}
