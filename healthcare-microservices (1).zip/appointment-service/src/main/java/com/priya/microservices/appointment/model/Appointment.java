package com.priya.microservices.appointment.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.sql.Timestamp;

@Entity
public class Appointment {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long patientId;
    private Long doctorId;
    private String symptoms;
    private LocalDateTime scheduledTime;
    private String status;
    private Timestamp createdAt = new Timestamp(System.currentTimeMillis());
    //getters/setters
    public Long getId(){return id;} public void setId(Long id){this.id=id;}
    public Long getPatientId(){return patientId;} public void setPatientId(Long patientId){this.patientId=patientId;}
    public Long getDoctorId(){return doctorId;} public void setDoctorId(Long doctorId){this.doctorId=doctorId;}
    public String getSymptoms(){return symptoms;} public void setSymptoms(String symptoms){this.symptoms=symptoms;}
    public LocalDateTime getScheduledTime(){return scheduledTime;} public void setScheduledTime(LocalDateTime scheduledTime){this.scheduledTime=scheduledTime;}
    public String getStatus(){return status;} public void setStatus(String status){this.status=status;}
    public Timestamp getCreatedAt(){return createdAt;} public void setCreatedAt(Timestamp createdAt){this.createdAt=createdAt;}
}
