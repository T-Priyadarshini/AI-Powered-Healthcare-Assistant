package com.priya.microservices.appointment.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.priya.microservices.appointment.repository.AppointmentRepository;
import com.priya.microservices.appointment.feign.PatientClient;
import com.priya.microservices.appointment.feign.DoctorClient;
import com.priya.microservices.appointment.dto.PatientDto;
import com.priya.microservices.appointment.dto.DoctorDto;
import com.priya.microservices.appointment.model.Appointment;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class AppointmentService {
    @Autowired private AppointmentRepository repo;
    @Autowired private PatientClient patientClient;
    @Autowired private DoctorClient doctorClient;

    public Appointment createAppointment(Long patientId, String symptoms, LocalDateTime preferredTime) {
        PatientDto p = patientClient.getPatient(patientId);
        if (p==null) throw new RuntimeException("Patient not found");
        // simple rule to pick specialty
        String specialty = symptoms.toLowerCase().contains("chest") ? "Cardiology" : "General Medicine";
        List<DoctorDto> doctors = doctorClient.findBySpecialty(specialty);
        if (doctors.isEmpty()) throw new RuntimeException("No doctors available for " + specialty);
        DoctorDto chosen = doctors.get(0);
        Appointment a = new Appointment();
        a.setPatientId(patientId); a.setDoctorId(chosen.getId());
        a.setSymptoms(symptoms); a.setScheduledTime(preferredTime); a.setStatus("PENDING");
        return repo.save(a);
    }

    public Appointment getById(Long id){ return repo.findById(id).orElse(null); }
}
