package com.priya.microservices.doctor.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.priya.microservices.doctor.model.Doctor;
import java.util.List;

public interface DoctorRepository extends JpaRepository<Doctor, Long> {
    List<Doctor> findBySpecialtyAndAvailableTrue(String specialty);
}
