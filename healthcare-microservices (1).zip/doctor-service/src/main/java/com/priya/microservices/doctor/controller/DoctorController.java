package com.priya.microservices.doctor.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import com.priya.microservices.doctor.model.Doctor;
import com.priya.microservices.doctor.repository.DoctorRepository;

@RestController
@RequestMapping("/doctors")
public class DoctorController {
    @Autowired private DoctorRepository repo;

    @PostMapping
    public Doctor create(@RequestBody Doctor d){ return repo.save(d); }

    @GetMapping("/by-specialty/{specialty}")
    public List<Doctor> bySpecialty(@PathVariable String specialty){
        return repo.findBySpecialtyAndAvailableTrue(specialty);
    }
}
